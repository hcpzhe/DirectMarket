var number1 = false;
var loginpwd1 = false;
var qrloginpwd1 = false;
var onepwd1 = false;
var qronepwd1 = false;
var twopwd1 = false;
var rtwopwd1 = false;
var tjnumber1 = false;
var jdnumber1 = false;
var bdnumber1 = false;
var name1 = false;
var tel1 = false;
var card1 = false;
var address1 = false;
var location1 = false;
$(function() {
	$("#number").blur(function() {
		number1 = false;
		$("#error1\\.info").html("");
		var number = $(this).val();
		if (number == "") {
			$("#error1\\.info").html("会员编号不能为空");
			return;
		}
		if (number.length < 6 || number.length > 8) {
			$("#error1\\.info").html("会员编号长度6-8位");
			return;
		}
		$.post("checkUsername", {
			"number" : number
		}, function(data) {
			if (data) {
				$("#error1\\.info").css( {
					color : "green"
				});
				$("#error1\\.info").html("会员编号可以使用");
				number1 = true;
			} else {
				$("#error1\\.info").css( {
					color : "red"
				});
				$("#error1\\.info").html("会员编号已被占用");
			}
		});
	});
	$("#loginpwd").blur(function() {
		loginpwd1 = false;
		$("#error2\\.info").html("");
		var loginpwd = $(this).val();
		var qrloginpwd = $("#qrloginpwd").val();
		if (qrloginpwd == "") {
			if (loginpwd == "") {
				$("#error2\\.info").html("登录密码不能为空");
				return;
			}
		} else {
			if (loginpwd != qrloginpwd) {
				$("#error2\\.info").html("两次输入的密码不一致");
				return;
			}
		}
		loginpwd1 = true;
	});
	$("#qrloginpwd").blur(function() {
		qrloginpwd1 = false;
		$("#error3\\.info").html("");
		var qrloginpwd = $(this).val();
		if (qrloginpwd == "") {
			$("#error3\\.info").html("请再次输入登录密码");
			return;
		}
		var loginpwd = $("#loginpwd").val();
		if (loginpwd != qrloginpwd) {
			$("#error3\\.info").html("两次输入的密码不一致");
			return;
		}
		qrloginpwd1 = true;
	});
	$("#onepwd").blur(function() {
		onepwd1 = false;
		$("#error4\\.info").html("");
		var onepwd = $(this).val();
		var qronepwd = $("#qronepwd").val();
		if (qronepwd == "") {
			if (onepwd == "") {
				$("#error4\\.info").html("请输入一级密码");
				return;
			}
		} else {
			if (onepwd != qronepwd) {
				$("#error4\\.info").html("两次输入的密码不一致");
				return;
			}
		}
		onepwd1 = true;
	});
	$("#qronepwd").blur(function() {
		qronepwd1 = false;
		$("#error5\\.info").html("");
		var qronepwd = $(this).val();
		if (qronepwd == "") {
			$("#error5\\.info").html("请再次输入一级密码");
			return;
		}
		var onepwd = $("#onepwd").val();
		if (onepwd != qronepwd) {
			$("#error5\\.info").html("两次输入的密码不一致");
			return;
		}
		qronepwd1 = true;
	});
	$("#twopwd").blur(function() {
		twopwd1 = false;
		$("#error6\\.info").html("");
		var twopwd = $(this).val();
		var rtwopwd = $("#rtwopwd").val();
		if (rtwopwd == "") {
			if (twopwd == "") {
				$("#error6\\.info").html("请输入取款密码");
				return;
			}
		} else {
			if (twopwd != rtwopwd) {
				$("#error6\\.info").html("两次输入的密码不一致");
				return;
			}
		}
		twopwd1 = true;
	});
	$("#rtwopwd").blur(function() {
		rtwopwd1 = false;
		$("#error7\\.info").html("");
		var rtwopwd = $(this).val();
		if (rtwopwd == "") {
			$("#error7\\.info").html("请再次输入取款密码");
			return;
		}
		var twopwd = $("#twopwd").val();
		if (twopwd != rtwopwd) {
			$("#error7\\.info").html("两次输入的密码不一致");
			return;
		}
		rtwopwd1 = true;
	});
	$("#tjnumber").blur(function() {
		tjnumber1 = false;
		$("#error8\\.info").html("");
		var tjnumber = $(this).val();
		if (tjnumber == "") {
			$("#error8\\.info").html("请输入推荐人编号");
			return;
		}
		$.post("checkUsername", {
			"number" : tjnumber
		}, function(data) {
			if (data) {
				$("#error8\\.info").css( {
					color : "red"
				});
				$("#error8\\.info").html("会员编号不存在不能推荐");
			} else {
				$("#error8\\.info").css( {
					color : "green"
				});
				$("#error8\\.info").html("会员编号可以使用");
				tjnumber1 = true;
			}
		});
	});
	$("#jdnumber").blur(function() {
		jdnumber1 = false;
		$("#error9\\.info").html("");
		var jdnumber = $(this).val();
		if (jdnumber == "") {
			$("#error9\\.info").html("请输入接点编号");
			return;
		}
		// 待修改
			$.post("checkUsername", {
				"number" : jdnumber
			}, function(data) {
				if (data) {
					$("#error9\\.info").css( {
						color : "red"
					});
					$("#error9\\.info").html("该编号不存在不能作为接点");
				} else {
					$("#error9\\.info").css( {
						color : "green"
					});
					$("#error9\\.info").html("节点存在可以作为节点");
					jdnumber1 = true;
				}
			});
		});
	$("#bdnumber").blur(function() {
		bdnumber1 = false;
		$("#error10\\.info").html("");
		var bdnumber = $(this).val();
		if (bdnumber == "") {
			$("#error10\\.info").html("请输入报单编号");
			return;
		}
		$.post("checkbdnumber", {
			"number" : bdnumber
		}, function(data) {
			if (data) {
				$("#error10\\.info").css( {
					color : "red"
				});
				$("#error10\\.info").html("编号不存在或者不是报单中心");
			} else {
				$("#error10\\.info").css( {
					color : "green"
				});
				$("#error10\\.info").html("报单编号可以使用");
				bdnumber1 = true;
			}
		});
	});
	// 所在位置
	$("#location").change(function() {
		location1 = false;
		$("#error11\\.info").html("");
		var location = $(this).val();
		var jdnumber = $("#jdnumber").val();
		if (location != "A" && location != "B") {
			$("#error11\\.info").html("请选择节点位置");
			return;
		}
		$.post("checkLocation", {
			"location" : location,
			"parentnumber" : jdnumber
		}, function(data) {
			if (data == "ok") {
				$("#error11\\.info").html("可以注册");
				location1 = true;
			}
			if (data == "afail") {
				$("#error11\\.info").html("该点不可以注册");
				return;
			}
			if (data == "qingzhucea") {
				$("#error11\\.info").html("请先注册或者激活A区");
				return;
			}
			if (data == "bfail") {
				$("#error11\\.info").html("该点不可以注册");
				return;
			}
			if (data == "fail") {
				$("#error11\\.info").html("请先输入接点编号");
				return;
			}
		});
	});
	//
	$("#name").blur(function() {
		name1 = false;
		$("#error12\\.info").html("");
		var name = $(this).val();
		if (name == "") {
			$("#error12\\.info").html("请输入真实姓名");
			return;
		}
		name1 = true;
	});
	$("#tel").blur(function() {
		tel1 = false;
		$("#error13\\.info").html("");
	//	var mobile = /^((1[3-8]{1}[0-9]{1}))+\d{8}$/;
		var tel = $(this).val();
		if (tel == "") {
			$("#error13\\.info").html("请输入手机号");
			return;
		}
		//if (!mobile.test(tel)) {
		//	$("#error13\\.info").html("手机号不正确请重新输入");
		//	return;
		//}
		tel1 = true;
	});
	$("#card").blur(function() {
		card1 = false;
		$("#error16\\.info").html("");
	//	var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
		var card = $(this).val();
		if (card == "") {
			$("#error16\\.info").html("请输入身份证号");
			return;
		}
	//	if (!reg.test(card)) {
		//	$("#error16\\.info").html(" 您输入身份证号不合法");
	//		return;
	//	}
		card1 = true;
	});
	$("#address").blur(function() {
		address1 = false;
		$("#error17\\.info").html("");
		var address = $(this).val();
		if (address == "") {
			$("#error17\\.info").html("请输入联系地址");
			return;
		}
		address1 = true;
	});
	$("#tj").submit(
			function() {
				var ok = number1 && loginpwd1 && qrloginpwd1 && onepwd1
						&& qronepwd1 && twopwd1 && rtwopwd1 && tjnumber1
						&& parentnumber1 && bdnumber1 && name1 && tel1 && card1
						&& address1 && location1;
				if (!ok) {
					alert("您的输入有误请核对");
					return false;
				}

			});

});