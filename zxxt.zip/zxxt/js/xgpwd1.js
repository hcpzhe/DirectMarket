var oldonepwd1 = false;
var newonepwd1 = false;
var rnewonepwd1 = false;
$(function() {
	$("#oldonepwd").blur(function() {
		oldonepwd1 = false;
		var oldonepwd = $(this).val();
		if (oldonepwd == "") {
			alert("请输入旧一级密码");
			return;
		}
		$.post("checkoldonepwd", {
			"oldonepwd" : oldonepwd
		}, function(data) {
			if (!data) {
				alert("旧一级密码输入错误");
				return;
			}
			oldonepwd1 = true;
		});
	});
	$("#newonepwd").blur(function() {
		newonepwd1 = false;
		var newonepwd = $(this).val();
		if (newonepwd == "") {
			alert("请输入新一级密码");
			return;
		}
		newonepwd1 = true;
	});
	$("#rnewonepwd").blur(function() {
		rnewonepwd1 = false;
		var rnewonepwd = $(this).val();
		var newonepwd = $("#newonepwd").val();
		if (rnewonepwd == "") {
			alert("请再次输入新一级密码");
			return;
		}
		if (rnewonepwd != newonepwd) {
			alert("两次输入密码不一致");
			return;
		}
		rnewonepwd1 = true;
	});
	$("#xg1").submit(function() {
		var ok = oldonepwd1 && newonepwd1 && rnewonepwd1;
		if (!ok) {
			alert("您的输入有误请核对");
			return;
		} else {
			var newonepwd = $("#newonepwd").val();
			var rnewonepwd = $("#rnewonepwd").val();
			$.post("xgoldonepwd", {
				"newonepwd" : newonepwd,
				"rnewonepwd" : rnewonepwd
			}, function(data) {
				if (data) {
					alert("一级密码修改成功");
				}
			});
			return false;
		}
	});
});