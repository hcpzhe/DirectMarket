    var emailtitle1 = false;
	var contents1 = false;
	$(function() {
		$("#emailtitle").blur(function() {
			emailtitle1 = false;
			var emailtitle = $(this).val();
			if (emailtitle == "") {
				alert("请输入邮件标题");
				return;
			}
			emailtitle1 = true;
		});
		$("#contents").blur(function() {
			contents1 = false;
			var contents = $(this).val();
			if (contents == "") {
				alert("请输入邮件内容");
				return;
			}
			contents1 = true;
		});
		$("#ml").submit(function() {
			var ok = emailtitle1 && contents1;
			if (!ok) {
				alert("您的输入有错误请核对");
				return false;
			}
		});
	});