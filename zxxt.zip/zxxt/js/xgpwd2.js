var oldtwopwd1 = false;
var newtwopwd1 = false;
var rnewtwopwd1 = false;
$(function() {
	$("#oldtwopwd").blur(function() {
		oldtwopwd1 = false;
		var oldtwopwd = $(this).val();
		if (oldtwopwd == "") {
			alert("请输入旧取款密码");
			return;
		}
		$.post("checkQukuanpwd", {
			"oldtwopwd" : oldtwopwd
		}, function(data) {
			if (!data) {
				alert("旧取款密码输入错误");
				return;
			}
			oldtwopwd1 = true;
		});
	});
	$("#newtwopwd").blur(function() {
		newtwopwd1 = false;
		var newtwopwd = $(this).val();
		if (newtwopwd == "") {
			alert("请输入新取款密码");
			return;
		}
		newtwopwd1 = true;
	});
	$("#rnewtwopwd").blur(function() {
		rnewtwopwd1 = false;
		var rnewtwopwd = $(this).val();
		var newtwopwd = $("#newtwopwd").val();
		if (rnewtwopwd == "") {
			alert("请再次输入新取款密码");
			return;
		}
		if (rnewtwopwd != newtwopwd) {
			alert("两次输入不一致");
			return;
		}
		rnewtwopwd1 = true;
	});
	$("#xg2").submit(function() {
		var ok = oldtwopwd1 && newtwopwd1 && rnewtwopwd1;
		if (!ok) {
			alert("您的输入有误请核对");
			return;
		} else {
			var newtwopwd = $("#newtwopwd").val();
			var rnewtwopwd = $("#rnewtwopwd").val();
			$.post("xgQukuanpwd", {
				"newtwopwd" : newtwopwd,
				"rnewtwopwd" : rnewtwopwd
			}, function(data) {
				if (data) {
					alert("取款密码修改成功");
				}
			});
			return false;
		}
	});
});