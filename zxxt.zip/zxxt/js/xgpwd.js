var oldloginpwd1 = false;
var newloginpwd1 = false;
var rnewloginpwd1 = false;
$(function() {
	$("#oldloginpwd").blur(function() {
		oldloginpwd1 = false;
		var oldloginpwd = $(this).val();
		if (oldloginpwd == "") {
			alert("请输入旧登录密码");
			return;
		}
		$.post("checkLoginpwd", {
			"oldloginpwd" : oldloginpwd
		}, function(data) {
			if (!data) {
				alert("旧登录密码输入错误");
				return;
			}
			oldloginpwd1 = true;
		});
	});
	$("#newloginpwd").blur(function() {
		newloginpwd1 = false;
		var newloginpwd = $(this).val();
		if (newloginpwd == "") {
			alert("请输入新登录密码");
			return;
		  } 
			newloginpwd1 = true;
	});
	$("#rnewloginpwd").blur(function() {
		rnewloginpwd1=false;
		var rnewloginpwd = $(this).val();
		var newloginpwd=$("#newloginpwd").val();
		if (rnewloginpwd == "") {
			alert("请再次输入新登录密码");
			return;
		}
		if(rnewloginpwd!=newloginpwd){
			alert("两次密码输入不一致");
			return;
		}
		rnewloginpwd1=true;
	});
	$("#xg").submit(function() {
		var ok = oldloginpwd1&&newloginpwd1&&rnewloginpwd1;
		if (!ok) {
			alert("您的输入有错请核对");
		} else {
			var newloginpwd = $("#newloginpwd").val();
			var rnewloginpwd = $("#rnewloginpwd").val();
			$.post("xgloginpwd", {
				"newloginpwd" : newloginpwd,
				"rnewloginpwd" : rnewloginpwd
			}, function(data) {
				if (data) {
					alert("登录密码修改成功");
				   }
			});
			return false;
		}
	});
});